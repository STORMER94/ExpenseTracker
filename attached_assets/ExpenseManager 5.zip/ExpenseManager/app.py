from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
from datetime import datetime
import bcrypt  # Import bcrypt

app = Flask(__name__)
app.secret_key = "your_secret_key"  # Change this!

# Database connection
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

# Helper function to get FY from a date
def get_fy_from_date(date_str):
    date_obj = datetime.strptime(date_str, '%Y-%m-%d')
    year = date_obj.year
    if date_obj.month >= 4:
        return f"{year}-{year + 1}"
    else:
        return f"{year - 1}-{year}"
    
def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Users table (for login -  VERY basic,  **INSECURE** for production)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT,
            last_name TEXT,
            date_of_birth DATE,
            gender TEXT,
            mobile_number TEXT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL  
        )
    ''')
    #  **NEVER** store passwords in plain text in production!  Use hashing (bcrypt, etc.)

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS expanse_heads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            head_name TEXT UNIQUE NOT NULL,
            created_on DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            expense_date DATE NOT NULL,
            fy TEXT NOT NULL,
            head_id INTEGER NOT NULL,
            transaction_details TEXT,
            transaction_type TEXT NOT NULL,
            transaction_amount REAL NOT NULL,
            created_on DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by TEXT,
            FOREIGN KEY (head_id) REFERENCES expanse_heads(id)
        )
    ''')

    conn.commit()
    conn.close()

init_db()  # Initialize the database when the app starts

# Login route
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if 'login' in request.form:  # Distinguish between login and signin
            email = request.form['email']
            password = request.form['password']  #  **INSECURE**
            conn = get_db_connection()
            user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone() #changed query
            conn.close()

            if user and bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')): # added bcrypt check
                session['user_id'] = user['id']
                session['user_email'] = user['email']
                return redirect(url_for('dashboard'))
            else:
                return render_template('login.html', error='Invalid credentials')
        elif 'signup' in request.form:
            # Handle sign-up
            first_name = request.form['first_name']
            last_name = request.form['last_name']
            date_of_birth = request.form['date_of_birth']
            gender = request.form['gender']
            mobile_number = request.form['mobile_number']
            email = request.form['email']
            password = request.form['password']
            confirm_password = request.form['confirm_password']

            if password != confirm_password:
                return render_template('login.html', error='Passwords do not match')

            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8') # Hash the password

            conn = get_db_connection()
            try:
                conn.execute('''
                    INSERT INTO users (first_name, last_name, date_of_birth, gender, mobile_number, email, password)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (first_name, last_name, date_of_birth, gender, mobile_number, email, hashed_password)) # Store hashed password
                conn.commit()
                conn.close()
                return redirect(url_for('login'))  # Redirect to login after successful sign-up
            except sqlite3.IntegrityError:
                conn.close()
                return render_template('login.html', error='Email already exists')

    return render_template('login.html')

# Dashboard route
@app.route('/dashboard')
def dashboard():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    conn = get_db_connection()

    # Get current month and FY
    now = datetime.now()
    current_month = now.month
    current_year = now.year
    current_fy = f"{current_year - 1}-{current_year}" if now.month < 4 else f"{current_year}-{current_year + 1}"

    # Chart 1: Date-wise Credit/Debit for Current Month
    chart1_data = conn.execute('''
        SELECT strftime('%Y-%m-%d', expense_date) as date, 
               SUM(CASE WHEN transaction_type = 'Credit' THEN transaction_amount ELSE 0 END) as credit,
               SUM(CASE WHEN transaction_type = 'Debit' THEN transaction_amount ELSE 0 END) as debit
        FROM expenses
        WHERE strftime('%m', expense_date) = ? AND fy = ?
        GROUP BY strftime('%Y-%m-%d', expense_date)
        ORDER BY strftime('%Y-%m-%d', expense_date)
    ''', (f"{current_month:02}", current_fy)).fetchall()
    
    chart1_labels = [row['date'] for row in chart1_data]
    chart1_credit_data = [row['credit'] for row in chart1_data]
    chart1_debit_data = [row['debit'] for row in chart1_data]

    # Chart 2: Month-wise Credit/Debit for Current FY
    chart2_data = conn.execute('''
        SELECT strftime('%m', expense_date) as month, 
               SUM(CASE WHEN transaction_type = 'Credit' THEN transaction_amount ELSE 0 END) as credit,
               SUM(CASE WHEN transaction_type = 'Debit' THEN transaction_amount ELSE 0 END) as debit
        FROM expenses
        WHERE fy = ?
        GROUP BY strftime('%m', expense_date)
        ORDER BY strftime('%m', expense_date)
    ''', (current_fy,)).fetchall()
    
    chart2_labels = [calendar.month_name[int(row['month'])] for row in chart2_data]  # Use calendar
    chart2_credit_data = [row['credit'] for row in chart2_data]
    chart2_debit_data = [row['debit'] for row in chart2_data]

    # Chart 3: Credit/Debit Pie Chart for Current Month
    chart3_data = conn.execute('''
        SELECT transaction_type, SUM(transaction_amount) as total
        FROM expenses
        WHERE strftime('%m', expense_date) = ? AND fy = ?
        GROUP BY transaction_type
    ''', (f"{current_month:02}", current_fy)).fetchall()
    
    chart3_labels = [row['transaction_type'] for row in chart3_data]
    chart3_values = [row['total'] for row in chart3_data]

    # Chart 4: Credit/Debit Pie Chart for Current FY
    chart4_data = conn.execute('''
        SELECT transaction_type, SUM(transaction_amount) as total
        FROM expenses
        WHERE fy = ?
        GROUP BY transaction_type
    ''', (current_fy,)).fetchall()
    
    chart4_labels = [row['transaction_type'] for row in chart4_data]
    chart4_values = [row['total'] for row in chart4_data]
    
    conn.close()

    return render_template('dashboard.html', 
                           user_email=session['user_email'],
                           chart1_labels=chart1_labels,
                           chart1_credit_data=chart1_credit_data,
                           chart1_debit_data=chart1_debit_data,
                           chart2_labels=chart2_labels,
                           chart2_credit_data=chart2_credit_data,
                           chart2_debit_data=chart2_debit_data,
                           chart3_labels=chart3_labels,
                           chart3_values=chart3_values,
                           chart4_labels=chart4_labels,
                           chart4_values=chart4_values,
                           current_month=current_month,
                           current_fy=current_fy)

# Expanse Master - List
@app.route('/expanse_master')
def expanse_master():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    conn = get_db_connection()
    # Join with the users table to get first_name and last_name
    heads = conn.execute('''
        SELECT eh.*, u.first_name, u.last_name
        FROM expanse_heads eh
        LEFT JOIN users u ON eh.created_by = u.email
    ''').fetchall()
    conn.close()
    return render_template('expanse_master.html', heads=heads)

# Expanse Master - Add
@app.route('/add_expanse_master', methods=['GET', 'POST'])
def add_expanse_master():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    if request.method == 'POST':
        head_name = request.form['head_name']
        conn = get_db_connection()
        conn.execute('INSERT INTO expanse_heads (head_name, created_by) VALUES (?, ?)', (head_name, session['user_email']))
        conn.commit()
        conn.close()
        return redirect(url_for('expanse_master'))
    return render_template('add_expanse_master.html')

# Expanse Master - Edit
@app.route('/edit_expanse_master/<int:head_id>', methods=['GET', 'POST'])
def edit_expanse_master(head_id):
    if not session.get('user_id'):
        return redirect(url_for('login'))
    conn = get_db_connection()
    head = conn.execute('SELECT * FROM expanse_heads WHERE id = ?', (head_id,)).fetchone()
    if not head:
        return "Head not found", 404  # Or redirect to a 404 page
    if request.method == 'POST':
        head_name = request.form['head_name']
        conn.execute('UPDATE expanse_heads SET head_name = ? WHERE id = ?', (head_name, head_id))
        conn.commit()
        conn.close()
        return redirect(url_for('expanse_master'))
    return render_template('edit_expanse_master.html', head=head)

# Expanse Master - Delete
@app.route('/delete_expanse_master/<int:head_id>')
def delete_expanse_master(head_id):
    if not session.get('user_id'):
        return redirect(url_for('login'))
    conn = get_db_connection()
    conn.execute('DELETE FROM expanse_heads WHERE id = ?', (head_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('expanse_master'))


# Expanse Form
@app.route('/expanse_form', methods=['GET', 'POST'])
def expanse_form():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    conn = get_db_connection()
    heads = conn.execute('SELECT id, head_name FROM expanse_heads').fetchall()
    conn.close()

    if request.method == 'POST':
        expense_date = request.form['expense_date']
        fy = get_fy_from_date(expense_date)
        head_id = request.form['head']
        transaction_details = request.form['transaction_details']
        transaction_type = request.form['transaction_type']
        transaction_amount = request.form['transaction_amount']

        conn = get_db_connection()
        conn.execute('''
            INSERT INTO expenses (expense_date, fy, head_id, transaction_details, transaction_type, transaction_amount, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (expense_date, fy, head_id, transaction_details, transaction_type, transaction_amount, session['user_email']))
        conn.commit()
        conn.close()
        return redirect(url_for('expanse_list'))
    return render_template('expanse_form.html',  heads=heads)

# Expanse List
@app.route('/expanse_list', methods=['GET', 'POST'])
def expanse_list():
    if not session.get('user_id'):
        return redirect(url_for('login'))

    conn = get_db_connection()
    heads = conn.execute('SELECT id, head_name FROM expanse_heads').fetchall()
    
    
    fy_filter = request.form.get('fy_filter')
    head_filter = request.form.get('head_filter')
    type_filter = request.form.get('type_filter')

    query = 'SELECT e.*, h.head_name FROM expenses e JOIN expanse_heads h ON e.head_id = h.id WHERE 1=1'
    params = []

    if fy_filter:
        query += ' AND e.fy = ?'
        params.append(fy_filter)
    if head_filter:
        query += ' AND e.head_id = ?'
        params.append(head_filter)
    if type_filter:
        query += ' AND e.transaction_type = ?'
        params.append(type_filter)

    expenses = conn.execute(query, params).fetchall()
    conn.close()
    
    # Get all unique FYs from the expenses table for the filter dropdown
    conn = get_db_connection()
    fys = conn.execute('SELECT DISTINCT fy FROM expenses').fetchall()
    conn.close()
    fy_options = [row['fy'] for row in fys]
    
    return render_template('expanse_list.html', expenses=expenses, fy_options=fy_options, heads=heads,
                           fy_filter=fy_filter, head_filter=head_filter, type_filter=type_filter)

# Expanse List - Edit
@app.route('/edit_expense/<int:expense_id>', methods=['GET', 'POST'])
def edit_expense(expense_id):
    if not session.get('user_id'):
        return redirect(url_for('login'))
    conn = get_db_connection()
    expense = conn.execute('SELECT * FROM expenses WHERE id = ?', (expense_id,)).fetchone()
    if not expense:
        return "Expense not found", 404
    heads = conn.execute('SELECT id, head_name FROM expanse_heads').fetchall()

    if request.method == 'POST':
        expense_date = request.form['expense_date']
        fy = get_fy_from_date(expense_date)
        head_id = request.form['head']
        transaction_details = request.form['transaction_details']
        transaction_type = request.form['transaction_type']
        transaction_amount = request.form['transaction_amount']

        conn.execute('''
            UPDATE expenses SET expense_date = ?, fy = ?, head_id = ?, transaction_details = ?, 
            transaction_type = ?, transaction_amount = ? WHERE id = ?
        ''', (expense_date, fy, head_id, transaction_details, transaction_type, transaction_amount, expense_id))
        conn.commit()
        conn.close()
        return redirect(url_for('expanse_list'))
    return render_template('edit_expense.html', expense=expense, heads=heads)

# Expanse List - Delete
@app.route('/delete_expense/<int:expense_id>')
def delete_expense(expense_id):
    if not session.get('user_id'):
        return redirect(url_for('login'))
    conn = get_db_connection()
    conn.execute('DELETE FROM expenses WHERE id = ?', (expense_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('expanse_list'))

# Logout
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user_email', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    import calendar
    app.run(debug=True)  # Remove debug=True in production!