// Function to render date-wise chart
function renderDateWiseChart(data) {
    const ctx = document.getElementById('dateWiseChart').getContext('2d');
    const dates = Object.keys(data);
    const creditAmounts = dates.map(date => data[date].credit || 0);
    const debitAmounts = dates.map(date => data[date].debit || 0);

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: dates,
            datasets: [{
                label: 'Credit',
                data: creditAmounts,
                backgroundColor: 'rgba(0, 123, 255, 0.7)', // Blue
                borderColor: 'rgba(0, 123, 255, 1)',
                borderWidth: 1
            }, {
                label: 'Debit',
                data: debitAmounts,
                backgroundColor: 'rgba(220, 53, 69, 0.7)', // Red
                borderColor: 'rgba(220, 53, 69, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Date-wise Credit and Debit'
            },
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
}

// Function to render month-wise chart
function renderMonthWiseChart(data) {
    const ctx = document.getElementById('monthWiseChart').getContext('2d');
    const months = Object.keys(data);
    const creditAmounts = months.map(month => data[month].credit || 0);
    const debitAmounts = months.map(month => data[month].debit || 0);

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: months,
            datasets: [{
                label: 'Credit',
                data: creditAmounts,
                backgroundColor: 'rgba(0, 123, 255, 0.7)', // Blue
                borderColor: 'rgba(0, 123, 255, 1)',
                borderWidth: 1
            }, {
                label: 'Debit',
                data: debitAmounts,
                backgroundColor: 'rgba(220, 53, 69, 0.7)', // Red
                borderColor: 'rgba(220, 53, 69, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Month-wise Credit and Debit'
            },
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
}

// Fetch data and render charts (simulated data for now)
document.addEventListener('DOMContentLoaded', () => {
    // Simulate fetching data from the server
    const dateWiseData = {
        '2023-01-01': { credit: 100, debit: 50 },
        '2023-01-05': { credit: 150, debit: 0 },
        '2023-01-10': { credit: 200, debit: 100 },
        '2023-01-15': { credit: 50, debit: 200 },
        '2023-01-20': { credit: 300, debit: 150 },
    };

    const monthWiseData = {
        'January': { credit: 500, debit: 200 },
        'February': { credit: 300, debit: 100 },
        'March': { credit: 600, debit: 400 },
        'April': {credit: 200, debit: 50}
    };

    renderDateWiseChart(dateWiseData);
    renderMonthWiseChart(monthWiseData);
});
